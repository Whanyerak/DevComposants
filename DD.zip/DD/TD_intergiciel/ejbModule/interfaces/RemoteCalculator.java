package interfaces;

import javax.ejb.Remote;

@Remote
public interface RemoteCalculator {
	int add(int a, int b);
}
