package src;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import interfaces.RemoteCalculator;

@Stateless
public class CalculatorBean implements RemoteCalculator{
	@PersistenceContext(name="BDDCalcul")
	public EntityManager em;
	
	@Override
	public int add(int a, int b) {
		CalculatorEntity ce = new CalculatorEntity();
		ce.setNum1(a);
		ce.setNum2(b);
		ce.setResultat(a+b);
		ce.setOperateur("+");
		em.persist(ce);
		return a + b;
	}
}
