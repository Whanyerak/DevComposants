package entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Panier
 *
 */
@Entity
@Table(name="Panier")
public class Panier implements Serializable {

	
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="Vehicules")
	private List<Vehicule> listVehicules;
	@Column(name="User")
	private User user;
	
	public Panier() {
		super();
	}

	public List<Vehicule> getListVehicules() {
		return listVehicules;
	}

	public void setListVehicules(List<Vehicule> listVehicules) {
		this.listVehicules = listVehicules;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
}
