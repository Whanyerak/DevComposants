package entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import enums.TypeVehicule;

/**
 * Entity implementation class for Entity: Vehicule
 *
 */
@Entity
@Table(name="Vehicule")
public class Vehicule implements Serializable {

	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name = "Type")
	private TypeVehicule typeVehicule;
	@Column(name = "Marque")
	private String marque;
	@Column(name = "Prix")
	private float prix;
	@Column(name="Quantite")
	private int quantite;
	@Column(name="Avis")
	private List<String> avis;
	
	public Vehicule() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public TypeVehicule getTypeVehicule() {
		return typeVehicule;
	}

	public void setTypeVehicule(TypeVehicule typeVehicule) {
		this.typeVehicule = typeVehicule;
	}

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}

	public List<String> getAvis() {
		return avis;
	}

	public void setAvis(List<String> avis) {
		this.avis = avis;
	}
   
}
