package enums;

public enum TypeVehicule {
	
	VOITURE(1),
	MOTO(2),
	VELO(3);
	
	private int code;
	
	private TypeVehicule(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}
	
}
