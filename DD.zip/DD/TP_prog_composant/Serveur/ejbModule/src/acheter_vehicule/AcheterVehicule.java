package src.acheter_vehicule;

public class AcheterVehicule implements IAcheterVehicule{

	@Override
	public void acheterVehicule(int id) {
		// TODO Auto-generated method stub
		
	}
	
}
