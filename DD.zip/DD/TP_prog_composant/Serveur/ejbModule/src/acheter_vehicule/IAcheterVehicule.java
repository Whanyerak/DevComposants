package src.acheter_vehicule;

public interface IAcheterVehicule {
	public void acheterVehicule(int id);
}
