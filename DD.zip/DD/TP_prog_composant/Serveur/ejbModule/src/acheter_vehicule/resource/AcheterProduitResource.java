package src.acheter_vehicule.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

import src.acheter_vehicule.AcheterVehicule;
import src.acheter_vehicule.IAcheterVehicule;

@Path("/Vehicule")
public class AcheterProduitResource {
	public IAcheterVehicule acheterVehicule;
	
	public AcheterProduitResource() {
		acheterVehicule = new AcheterVehicule();
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void acheterVehicule(@PathParam("id") int id) {
		this.acheterVehicule.acheterVehicule(id);
	}
}
