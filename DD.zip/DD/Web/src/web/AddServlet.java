package web;

import java.io.IOException;
import java.io.Writer;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import interfaces.RemoteCalculator;

@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private	static final long serialVersionUID = 1L;
	
	@EJB
	private	RemoteCalculator add;
	
	public	AddServlet() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer a = Integer.valueOf(request.getParameter("operand1"));
		Integer b = Integer.valueOf(request.getParameter("operand2"));
		Writer out = response.getWriter();
		out.write("<html><head><title>Result</title></head><body>");
		out.write("Result=" + add.add(a, b));
		out.write("</body></html>");
		out.flush();
		out.close();
	}
}
